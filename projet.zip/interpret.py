#pip install PyMuPDF
from tkinter import *
import fitz  # PyMuPDF
import TextSearch



def Chercher(fichier, motif):
    tableau = []
    file = fitz.open(fichier)

    for i in range(file.page_count):
        page = file[i]
        text = page.get_text()
        if TextSearch.boyer_moore(motif, text) !=-1:
            tableau.append(i + 1)  # Ajoute 1 car les pages commencent à partir de 1

    file.close()
    if tableau != []:
        result = f"Le motif : {motif} , a été trouvé aux pages : {tableau}"
        return result
    else:
        result = f"Le motif : {motif} , n'a pas été trouvé dans le fichier : {fichier} "
        return result



#lorem-ipsum.pdf
#pokemon_fixed.pdf