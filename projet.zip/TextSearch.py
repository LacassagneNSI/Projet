
def naif(motif,texte):

    tab =[]
    long_txt = len(texte)
    long_motif = len(motif)

    if motif == "":
        return "Veuillez entrer un motif"

    for i in range(long_txt-long_motif+1):
        if motif == texte[i:i+long_motif]:
            tab.append(i)
    return tab


##########################################################################

def saut(motif):  #Cela permet de calculer le saut a effectuer si la lettre est trouvé
    dico = {}
    long_motif = len(motif)

    for i in range(long_motif-1):
        dico[motif[i]] = long_motif-i -1
    return dico


def boyer_moore(motif,texte):
    tab = []
    long_txt = len(texte)
    long_motif = len(motif)
    table_saut = saut(motif)

    if motif == "":
        return "Veuillez entrer un motif"

    i=0
    while i <= long_txt - long_motif: #On parcoure le texte
        j = long_motif-1

        while j>= 0 and motif[j] == texte[i+j]: #On parcoure le motif
            j -=1

        if j <0:   #si tous les caractères du motif correspondent
            tab.append(i)
            i+= long_motif
        else:
            if texte[i+j] in table_saut:
                i += table_saut[texte[i+j]]
            else:
                i+= long_motif
    if tab == []:
        return -1
    return tab






if __name__ == '__main__':
    import doctest
    doctest.testmod()

motif1 = 'witch'
texte1 = 'A witch which switch'

motif2 = 'scribe'
texte2 = """Test document PDF

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla est purus, ultrices in porttitor
in, accumsan non quam. Nam consectetur porttitor rhoncus. Curabitur eu est et leo feugiat
auctor vel quis lorem. Ut et ligula dolor, sit amet consequat lorem. Aliquam porta eros sed
velit imperdiet egestas. Maecenas tempus eros ut diam ullamcorper id dictum libero
tempor. Donec quis augue quis magna condimentum lobortis. Quisque imperdiet ipsum vel
magna viverra rutrum. Cras viverra molestie urna, vitae vestibulum turpis varius id.
Vestibulum mollis, arcu iaculis bibendum varius, velit sapien blandit metus, ac posuere lorem
nulla ac dolor. Maecenas urna elit, tincidunt in dapibus nec, vehicula eu dui. Duis lacinia
fringilla massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur
ridiculus mus. Ut consequat ultricies est, non rhoncus mauris congue porta. Vivamus viverra
suscipit felis eget condimentum. Cum sociis natoque penatibus et magnis dis parturient
montes, nascetur ridiculus mus. Integer bibendum sagittis ligula, non faucibus nulla volutpat
vitae. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.
In aliquet quam et velit bibendum accumsan. Cum sociis natoque penatibus et magnis dis
parturient montes, nascetur ridiculus mus. Vestibulum vitae ipsum nec arcu semper
adipiscing at ac lacus. Praesent id pellentesque orci. Morbi congue viverra nisl nec rhoncus.
Integer mattis, ipsum a tincidunt commodo, lacus arcu elementum elit, at mollis eros ante ac
risus. In volutpat, ante at pretium ultricies, velit magna suscipit enim, aliquet blandit massa
orci nec lorem. Nulla facilisi. Duis eu vehicula arcu. Nulla facilisi. Maecenas pellentesque
volutpat felis, quis tristique ligula luctus vel. Sed nec mi eros. Integer augue enim, sollicitudin
ullamcorper mattis eget, aliquam in est. Morbi sollicitudin libero nec augue dignissim ut
consectetur dui volutpat. Nulla facilisi. Mauris egestas vestibulum neque cursus tincidunt.
Donec sit amet pulvinar orci.
Quisque volutpat pharetra tincidunt. Fusce sapien arcu, molestie eget varius egestas,
faucibus ac urna. Sed at nisi in velit egestas aliquam ut a felis. Aenean malesuada iaculis nisl,
ut tempor lacus egestas consequat. Nam nibh lectus, gravida sed egestas ut, feugiat quis
dolor. Donec eu leo enim, non laoreet ante. Morbi dictum tempor vulputate. Phasellus
ultricies risus vel augue sagittis euismod. Vivamus tincidunt placerat nisi in aliquam. Cras
quis mi ac nunc pretium aliquam. Aenean elementum erat ac metus commodo rhoncus.
Aliquam nulla augue, porta non sagittis quis, accumsan vitae sem. Phasellus id lectus tortor,
eget pulvinar augue. Etiam eget velit ac purus fringilla blandit. Donec odio odio, sagittis sed
iaculis sed, consectetur eget sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
Maecenas accumsan velit vel turpis rutrum in sodales diam placerat.
Quisque luctus ullamcorper velit sit amet lobortis. Etiam ligula felis, vulputate quis rhoncus
nec, fermentum eget odio. Vivamus vel ipsum ac augue sodales mollis euismod nec tellus.
Fusce et augue rutrum nunc semper vehicula vel semper nisl. Nam laoreet euismod quam at
varius. Sed aliquet auctor nibh. Curabitur malesuada fermentum lacus vel accumsan. Duis
ornare scelerisque nulla, ac pulvinar ligula tempus sit amet. In placerat nulla ac ante
scelerisque posuere. Phasellus at ante felis. Sed hendrerit risus a metus posuere rutrum.
Phasellus eu augue dui. Proin in vestibulum ipsum. Aenean accumsan mollis sapien, ut
eleifend sem blandit at. Vivamus luctus mi eget lorem lobortis pharetra. Phasellus at tortor
quam, a volutpat purus. Etiam sollicitudin arcu vel elit bibendum et imperdiet risus tincidunt.
Etiam elit velit, posuere ut pulvinar ac, condimentum eget justo. Fusce a erat velit. Vivamus
imperdiet ultrices orci in hendrerit."""

motif3 = 'ment'
texte3 = """Et d'abord, bourdonnement dans les oreilles, éblouissement dans
les yeux. Au-dessus de nos têtes une double voûte en ogive, lambrissée en
sculptures de bois, peinte d'azur, fleurdelysée en or; sous nos pieds, un pavé
alternatif de marbre blanc et noir. À quelques pas de nous, un énorme pilier,
véritable menhir, puis un autre, puis un autre; en tout sept piliers dans la
longueur de la salle, soutenant au milieu de sa largeur les retombées de la
double voûte. Autour des quatre premiers piliers, des boutiques de marchands,
tout étincelantes de verre et de clinquants; autour des trois derniers, des
bancs de bois de chêne, usés et polis par le haut-de-chausses des plaideurs et
la robe des procureurs. À l'entour de la salle, le long de la haute muraille,
entre les portes, entre les croisées, entre les piliers, l'interminable rangée
des statues de tous les rois de France depuis Pharamond; les rois fainéants,
les bras pendants et les yeux baissés; les rois vaillants et bataillards, la
tête et les mains hardiment levées au ciel."""

# print (boyer_moore(motif1, texte1) == [2, 15])
# print (boyer_moore(motif1, texte2) == f"Le texte ne contient pas le motif : witch")
# print (naif(motif1, texte1) == [2, 15])
# print(naif(motif1, texte2) == [])
# print (boyer_moore(motif2, texte2) == f"Le texte ne contient pas le motif : scribe")
# print(naif(motif2, texte2) == [])

