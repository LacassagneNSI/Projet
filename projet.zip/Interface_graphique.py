import tkinter as tk   #Le module qui permet d'afficher une interface graphique
from tkinter import filedialog  #Le module qui permet de sélectionner un fichier
import interpret  #Le module crée précédemment qui permet de parcourir un pdf

def on_chercher_clicked():
    fichier = entry_fichier.get()
    motif = entry_motif.get()
    result = Chercher(fichier, motif)
    result_text.config(state=NORMAL)
    result_text.delete(1.0, END)
    result_text.insert(END, result)
    result_text.config(state=DISABLED)

def choisir_fichier():
    filename = filedialog.askopenfilename(title="Choisir un fichier", filetypes=[("PDF files", "*.pdf")])
    entry_fichier.delete(0, END)
    entry_fichier.insert(0, filename)

# Création de la fenêtre principale
fenetre = tk.Tk()
fenetre.title("Chercher dans un PDF")

# Widget de texte pour afficher le résultat
result_text = tk.Text(fenetre, height=3, width=60)
result_text.config(state=tk.DISABLED)  # Pour rendre le texte en lecture seule

# Création des widgets
label_fichier = tk.Label(fenetre, text="Chemin du fichier PDF:")
entry_fichier = tk.Entry(fenetre, width=40)
btn_choisir_fichier = tk.Button(fenetre, text="Choisir un fichier", command=choisir_fichier)

label_motif = tk.Label(fenetre, text="Motif à chercher:")
entry_motif = tk.Entry(fenetre, width=40)

btn_chercher = tk.Button(fenetre, text="Chercher", command=on_chercher_clicked)

# Placement des widgets
label_fichier.grid(row=0, column=0, padx=10, pady=10, sticky="e")
entry_fichier.grid(row=0, column=1, padx=10, pady=10)
btn_choisir_fichier.grid(row=0, column=2, padx=10, pady=10)

label_motif.grid(row=1, column=0, padx=10, pady=10, sticky="e")
entry_motif.grid(row=1, column=1, padx=10, pady=10)

btn_chercher.grid(row=2, column=1, pady=20)
result_text.grid(row=3, column=0, columnspan=3, padx=10, pady=10)

# Lancement de la boucle principale
fenetre.mainloop()
