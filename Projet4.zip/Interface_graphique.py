from tkinter import *
from tkinter import filedialog
import pdf_to_python

def on_chercher_clicked():
    """
    Fonction appelée lors du clic sur le bouton "Chercher".
    Récupère le chemin du fichier PDF et le motif depuis les entrées utilisateur,
    utilise la fonction Chercher pour rechercher le motif dans le fichier,
    puis affiche le résultat dans la boîte de texte désactivée.
    """
    fichier = entry_fichier.get()
    motif = entry_motif.get()
    if CocheC1.get() == 1:
        result = pdf_to_python.Chercher_boyer_moore(fichier, motif)
    else:
        result = pdf_to_python.Chercher_naif(fichier, motif)
    result_text.config(state=NORMAL)
    result_text.delete(1.0, END)
    result_text.insert(END, result)
    result_text.config(state=DISABLED)

def choisir_fichier():
    """
    Fonction appelée lors du clic sur le bouton "Choisir un fichier".
    Ouvre une boîte de dialogue pour permettre à l'utilisateur de choisir un fichier PDF,
    puis met à jour le champ de saisie du chemin du fichier avec le chemin sélectionné.
    """
    filename = filedialog.askopenfilename(title="Choisir un fichier", filetypes=[("PDF files", "*.pdf")])
    entry_fichier.delete(0, END)
    entry_fichier.insert(0, filename)

def choisir_algo(variable):
    """
    Décoche la case 2 si la 1 est coché, et vice versa
    variable - Variable associée à une case à cocher. (1 case cochée, 0 non cochée)
    """
    if variable.get() == 1:
        if variable is CocheC1:
            CocheC2.set(0)
        elif variable is CocheC2:
            CocheC1.set(0)

# Création de la fenêtre principale
fenetre = Tk()
fenetre.title("Chercher dans un PDF")
fenetre.minsize(800, 300)
fenetre.configure(bg="#0169a6")

# Boite de texte pour afficher le résultat
result_text = Text(fenetre, height=5, width=60, bg="white")
result_text.config(state=DISABLED, wrap=WORD)

# Création de la boite Chemin du fichier PDF
label_fichier = Label(fenetre, text="Chemin du fichier PDF:", font=("Helvetica", 12), bg="#0169a6", fg="white")
entry_fichier = Entry(fenetre, width=40, font=("Helvetica", 12), bg="white", fg="black")
btn_choisir_fichier = Button(fenetre, text="Choisir un fichier 📁", command=choisir_fichier, font=("Helvetica", 12), bg="white", fg="#0169a6")

# Création de la boite Motif à chercher
label_motif = Label(fenetre, text="Motif à chercher:", font=("Helvetica", 12), bg="#0169a6", fg="white")
entry_motif = Entry(fenetre, width=40, font=("Helvetica", 12), bg="white", fg="black")

# Création des boutons pour choisir l'algorithme
CocheC1 = IntVar()
CocheC2 = IntVar()

C1 = Checkbutton(fenetre, text="Booyer Moore", variable=CocheC1, onvalue=1, offvalue=0, bg="#0169a6", fg="white", selectcolor="#0169a6", command=lambda: choisir_algo(CocheC1))
C2 = Checkbutton(fenetre, text="Naif", variable=CocheC2, onvalue=1, offvalue=0, bg="#0169a6", fg="white", selectcolor="#0169a6", command=lambda: choisir_algo(CocheC2))
CocheC1.set(1)

# Création du bouton qui lance la recherche
btn_chercher = Button(fenetre, text="Chercher 🔎", command=on_chercher_clicked, font=("Helvetica", 12), bg="white", fg="#0169a6")

# Placement des différents éléments sur la grille de la fenetre
label_fichier.grid(row=0, column=0, padx=10, pady=10)
entry_fichier.grid(row=0, column=1, padx=10, pady=10)
btn_choisir_fichier.grid(row=0, column=2, padx=10, pady=10)

label_motif.grid(row=1, column=0, padx=10, pady=10)
entry_motif.grid(row=1, column=1, padx=10, pady=10)

btn_chercher.grid(row=2, column=1, pady=20)
result_text.grid(row=3, column=0, columnspan=3, padx=10, pady=10)

C1.grid(row=2, column=0, pady=20)
C2.grid(row=2, column=2 , pady=10, padx=10)

# Ouvrir la fenetre a l'exécution
fenetre.mainloop()
