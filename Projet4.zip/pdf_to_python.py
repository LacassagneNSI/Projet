#pip install PyMuPDF
import fitz  # PyMuPDF
import TextSearch



def Chercher_boyer_moore(fichier, motif):
    """
    Recherche un motif dans un fichier PDF en utilisant l'algorithme de Boyer-Moore.

    fichier - str : Chemin vers le fichier PDF à analyser.
    motif - str : Motif à rechercher dans le contenu du fichier PDF.

    return: Message indiquant si le motif a été trouvé et les pages correspondantes, ou un message d'absence.

    """
    tableau = []
    file = fitz.open(fichier)

    for i in range(file.page_count):
        page = file[i]
        texte = page.get_text()
        if TextSearch.boyer_moore(motif, texte) != "Le motif n'est pas présent dans le texte":
            tableau.append(i + 1)  # Ajoute 1 car les pages commencent à partir de 1

    file.close()
    if tableau != []:
        result = f"Le motif : {motif} , a été trouvé aux pages : {tableau} avec l'algorithme de Boyer Moore"
        return result
    else:
        result = f"Le motif : {motif} , n'a pas été trouvé dans le fichier : {fichier} "
        return result

def Chercher_naif(fichier, motif):
    """
    Recherche un motif dans un fichier PDF en utilisant l'algorithme naif.

    fichier - str : Chemin vers le fichier PDF à analyser.
    motif - str : Motif à rechercher dans le contenu du fichier PDF.

    return: Message indiquant si le motif a été trouvé et les pages correspondantes, ou un message d'absence.

    """
    tableau = []
    file = fitz.open(fichier)

    for i in range(file.page_count):
        page = file[i]
        texte = page.get_text()
        if TextSearch.naif(motif, texte) != "Le motif n'est pas présent dans le texte":
            tableau.append(i + 1)  # Ajoute 1 car les pages commencent à partir de 1

    file.close()
    if tableau != []:
        result = f"Le motif : {motif} , a été trouvé aux pages : {tableau} avec l'algorithme Naif"
        return result
    else:
        result = f"Le motif : {motif} , n'a pas été trouvé dans le fichier : {fichier} "
        return result



if __name__ == '__main__':
    import doctest
    doctest.testmod()





print("Test de la fonction Chercher_boyer_moore :")
fichier, motif = "LoremIpsum.pdf", "GTA VI"
print(Chercher_boyer_moore(fichier, motif) == f"Le motif : GTA VI , n'a pas été trouvé dans le fichier : LoremIpsum.pdf ")
fichier, motif = "LoremIpsum.pdf", "Lorem"
print(Chercher_boyer_moore(fichier, motif) == "Le motif : Lorem , a été trouvé aux pages : [1, 2, 3, 4, 5, 6, 7, 8, 9] avec l'algorithme de Boyer Moore")

print("Test de la fonction Chercher_naif :")
fichier, motif = "LoremIpsum.pdf", "NSI"
print(Chercher_naif(fichier, motif) == f"Le motif : NSI , n'a pas été trouvé dans le fichier : LoremIpsum.pdf ")
fichier, motif = "LoremIpsum.pdf", "dolor"
print(Chercher_naif(fichier, motif) == "Le motif : dolor , a été trouvé aux pages : [1, 2, 3, 4, 5, 6, 7, 8, 9] avec l'algorithme Naif")