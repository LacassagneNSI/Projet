def naif(motif,texte):
    """
    Recherche un motif dans un texte en utilisant l'algorithme de recherche naïve.

    motif - str : Motif à rechercher dans le texte.
    texte - str : Texte dans lequel le motif sera recherché.

    return: Liste des indices de début du motif dans le texte, ou un message indiquant l'absence du motif.
             Si le motif est vide, le message "Veuillez entrer un motif" est retourné.
    """
    tab =[]
    long_txt = len(texte)
    long_motif = len(motif)

    if motif == "":
        return "Veuillez entrer un motif"

    for i in range(long_txt-long_motif+1):
        if motif == texte[i:i+long_motif]:
            tab.append(i)
    if tab == []:
        return "Le motif n'est pas présent dans le texte"
    return tab


##########################################################################

def saut(motif):  #Cela permet de calculer le saut a effectuer si la lettre est trouvé
    """
    Calcule le saut à effectuer si une lettre du motif est trouvée.

    motif - str : Motif pour lequel le saut est calculé.

    return: Dictionnaire contenant les sauts associés à chaque lettre du motif.
    """
    dico = {}
    long_motif = len(motif)

    for i in range(long_motif-1):
        dico[motif[i]] = long_motif-i -1
    return dico


def boyer_moore(motif,texte):
    """
    Recherche un motif dans un texte en utilisant l'algorithme de Boyer-Moore.

    motif - str : Motif à rechercher dans le texte.
    texte - str : Texte dans lequel le motif sera recherché.

    return: Liste des indices de début du motif dans le texte, ou un message indiquant l'absence du motif.
    Si le motif est vide, le message "Veuillez entrer un motif" est retourné.
    """

    tab = []
    long_txt = len(texte)
    long_motif = len(motif)
    table_saut = saut(motif)

    if motif == "":
        return "Veuillez entrer un motif"

    i=0
    while i <= long_txt - long_motif: #On parcoure le texte
        j = long_motif-1

        while j>= 0 and motif[j] == texte[i+j]: #On parcoure le motif
            j -=1

        if j <0:   #si tous les caractères du motif correspondent
            tab.append(i)
            i+= long_motif
        else:
            if texte[i+j] in table_saut:
                i += table_saut[texte[i+j]]
            else:
                i+= long_motif
    if tab == []:
        return "Le motif n'est pas présent dans le texte"
    return tab






if __name__ == '__main__':
    import doctest
    doctest.testmod()


texte1 = """
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed non risus.
Suspendisse lectus tortor, dignissim sit amet, adipiscing nec, ultricies sed,
dolor. Cras elementum ultrices diam. Maecenas ligula massa, varius a, semper
congue, euismod non, mi. Proin porttitor, orci nec nonummy molestie, enim est
eleifend mi, non fermentum diam nisl sit amet erat. Duis semper. Duis arcu massa,
scelerisque vitae, consequat in, pretium a, enim. Pellentesque congue. Ut in
risus volutpat libero pharetra tempor. Cras vestibulum bibendum augue. Praesent
egestas leo in pede. Praesent blandit odio eu enim. Pellentesque sed dui ut
augue blandit sodales. Vestibulum ante ipsum primis in faucibus orci luctus et
ultrices posuere cubilia Curae; Aliquam nibh. Mauris ac mauris sed pede
pellentesque fermentum. Maecenas adipiscing ante non diam sodales hendrerit.
Ut velit mauris, egestas sed, gravida nec, ornare ut, mi. Aenean ut orci vel
massa suscipit pulvinar. Nulla sollicitudin. Fusce varius, ligula non tempus
aliquam, nunc turpis ullamcorper nibh, in tempus sapien eros vitae ligula.
"""



print("Test de la fonction naif :")
print(naif("libero",texte1) == [480])
print(naif("ameno",texte1) == "Le motif n'est pas présent dans le texte")
print(naif("ipsum",texte1) == [7, 660])
print(naif("",texte1) == "Veuillez entrer un motif")

print("Test de la fonction boyer_moore :")
print(boyer_moore("libero",texte1) == [480])
print(boyer_moore("ameno",texte1) == "Le motif n'est pas présent dans le texte")
print(boyer_moore("ipsum",texte1) == [7, 660])
print(boyer_moore("",texte1) == "Veuillez entrer un motif")



